# Manhole cover detection > 2023-12-26 9:14pm
https://universe.roboflow.com/manhole-pqaet/manhole-cover-detection-vpioj

Provided by a Roboflow user
License: CC BY 4.0

